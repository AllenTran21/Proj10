//package proj10.mailorder;

public class Customer {

    private String fullName = "";
    private Address address = new Address("", "", "", 0);
    private int customerNumber = 0;
    private static int customersCreated;

    public Customer(String fullName, Address address) {
        this.fullName = fullName;
        this.address = address;
        this.customerNumber = customersCreated;
        customersCreated++;
    }

    public int getCustomerNbr() {
        return this.customerNumber;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    @Override
    public String toString() {
        String firstName = fullName.substring(0, fullName.indexOf(" "));
        String middleName = fullName.substring(fullName.indexOf(" "), fullName.lastIndexOf(" "));
        String lastName = fullName.substring(fullName.lastIndexOf(" ") + 1, fullName.length());

        String streetAddress;
        String city;
        String state;
        int zip;

        if ("middleName".length() == 0) {
            return String.format(
                    "Customer Nbr: %d\n%s, %s\nBilling Address:\n%s",
                    getCustomerNbr(), lastName, firstName,
                    address);
            //address.toString());
        } else {
            return String.format(
                    "Customer Nbr: %d\n%s, %s%s\nBilling Address:\n%s",
                    getCustomerNbr(), lastName, firstName, middleName,
                    address);
            //address.toString());
        }
    }

    public static int getNbrOfCustomers() {
        return 0;
    }
}
