//package proj10.mailorder;

public class Address {

    private String streetAddress = "";
    private String city = "";
    private String state = "";
    private int zip = 0;

    public Address(String streetAddress, String city, String state, int zip) {

        this.streetAddress = streetAddress;
        this.city = city;
        this.state = state;
        this.zip = zip;

    }

    @Override
    public String toString() {
        return String.format("%s\n%s, %s %05d", this.streetAddress,
                this.city, this.state, this.zip);
    }
//changed from static to nonstatic

    public static Address parse(String streetAddress, String cityStateZip) {
        String city = cityStateZip.substring(0, cityStateZip.indexOf(","));
        String state = cityStateZip.substring(city.length() + 2, cityStateZip.lastIndexOf(" "));
        int zip = Integer.parseInt(cityStateZip.substring(cityStateZip.lastIndexOf(" ") + 1, cityStateZip.length()));

        return new Address(streetAddress, city, state, zip);
    }
}
