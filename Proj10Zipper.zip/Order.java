//package proj10.mailorder;

import java.util.ArrayList;

public class Order {

    public Order(Customer customer, Address shippingAddress) {
    }

    public void addItem(OrderItem item) {

    }

    public Address getAddress() {
        return new Address("dummy", "dummy", "DU", 12345);
    }

    @Override
    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();

        stringBuilder.append("Order Number: ")
                .append("\nPurchased by:\n")
                .append("\nShipped to:\n")
                .append("\nItems Ordered:\n");

        stringBuilder.append(String.format("%-30s  $%7.2f",
                "Order Total: ", 0));

        return stringBuilder.toString();
    }
}
