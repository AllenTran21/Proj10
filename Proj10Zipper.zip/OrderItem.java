//package proj10.mailorder;

public class OrderItem {
private String description = "";
private double cost = 0;

    public OrderItem(String description, double cost) {
        this.description = description;
        this.cost = cost;
    }

    public double getCost() {
        return cost;
    }
    public String getName() {
        return description;
    }

    @Override
    public String toString() {
        return String.format("%-30s  $%7.2f", description, cost);
    }
}
